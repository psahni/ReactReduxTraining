
import React, {Component} from "react";
import PropTypes from "prop-types";

export default class CartItem extends Component {
    constructor(props) {
        super(props);
    }
    
    componentDidMount() {
        
    }
    
    render() {
        console.log("cart item");
        return (
            <div> 
            <h2>Cart Item</h2>
            </div>
        )
    }
} 


CartItem.defaultProps = {
    
}

CartItem.propTypes = {
    
}