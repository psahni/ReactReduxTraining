
import React, {Component} from "react";
import PropTypes from "prop-types";

import CartList from "./CartList";
import CartSummary from "./CartSummary";

export default class Cart extends Component {
    constructor(props) {
      super(props);
      this.state = {
        items: [],
        amount: 0,
        reload: true
      }
    }
    
    componentDidMount() {
       
    }

    addItem() {
      let id = Math.ceil(Math.random() * 100000);      
      let item = {
          id: id,
          name: 'Product '  + id,
          price: Math.ceil(Math.random() * 1000),
          qty: 0
      }
      this.state.items.push(item);
      this.forceUpdate();
      console.log("total items ", this.state.items.length);
    }

    removeItem() {

    }

    updateItem(id, qty) {

    }

    emptyCart() {

    }

    refresh() {

    }

    recalculate() {
      
    }
    
    render() {
        console.log("cart");
        return (
            <div> 
            <h2>Cart [{this.state.items.length}]</h2>
            <div>
              <button onClick={() => this.addItem()}>
                Add Item
              </button>
              <button>
                Empty
              </button>
              <button>
                Refresh
              </button>
            </div>
            <CartList >
            </CartList>

            <CartSummary>
            </CartSummary>
            </div>
        )
    }
} 


Cart.defaultProps = {
    
}

Cart.propTypes = {
    
}